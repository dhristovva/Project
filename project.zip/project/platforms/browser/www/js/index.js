const baseSurviceUrl= "https://baas.kinvey.com/appdata/kid_BypDIT0Uu/coordss";
const kinveyUsername = "guest";
const kinveyPassword = "1234";
const base64Auth = "Authorization" + "Basic" + btoa(kinveyUsername + ":" + kinveyPassword);

window.fn = {};

window.fn.open = function () {
    var menu = document.getElementById('menu');
    menu.open();
};

window.fn.load = function (page) {
    var content = document.getElementById('content');
    var menu = document.getElementById('menu');
    content.load(page)
        .then(menu.close.bind(menu));
};
    

var login = function() {
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;
  
    if (username === 'user' && password === '1234') {
      ons.notification.alert('Congratulations!');
    } else {
      ons.notification.alert('Incorrect username or password.');
    }
    
    $('#menulist').show();
  };

function Add(){ 
   
    let newLi=document.createElement('li');
    newLi.textContent=document.getElementById('input').value;
    document.getElementById('AddSubject').appendChild(newLi);
    document.getElementById('input').value="";
}
//
document.addEventListener('init', function(event) {

  ons.ready(function() {
  
    document.getElementById("deviceInfo").innerHTML=device.version + " is presented " + device.platform;
    window.addEventListener("batterystatus", onBatteryStatus, false);
  
  function onBatteryStatus(status) { 
  
      document.getElementById("batteryInfo").value=status.level;
      document.getElementById("batteryLevel").innerHTML= 'Status:'+ status.isPlugged;
    };
                 
      navigator.geolocation.watchPosition(geolocationSuccess, geolocationError);
  });
  
  function geolocationSuccess(position) {
      document.getElementById("latitude").innerHTML='Latitude:' + position.coords.latitude;
      document.getElementById("longitude").innerHTML='Longitude:' + position.coords.longitude;
      document.getElementById("altitude").innerHTML= 'Altitude:' + position.coords.altitude;
      document.getElementById("accuracy").innerHTML= 'Accuracy:' + position.coords.accuracy;
      document.getElementById("altitudeAccuracy").innerHTML= 'Altitude accuracy:' + position.coords.altitudeAccuracy;

      console.log(position);

  let positionEntity = {
		  latitude:position.coords.latitude,
		  longitude:position.coords.longitude,
		  altitude:position.coords.altitude,
		  accuracy:position.coords.accuracy,
		  altitudeAccuracy:position.coords.altitudeAccuracy,
		  timestamp:position.timestamp
	};
	  savePosition(positionEntity);
  }
  
  
function geolocationError(error) {
      alert('code: ' + error.code + '\n' +
          'message: ' + error.message + '\n');
  }

function savePosition(requestData){

  console.log(JSON.stringify(requestData));

  $.ajax({
    type:"POST",
    url: baseSurviceUrl,
    //beforeSend: function(xhr){
      //xhr.setRequestHeader("Authorization","Basic " + base64Auth);
    //},
    contentType: "application/json",
    dataType: "json",
    data: JSON.stringify(requestData),
    success: function(){
      alert("Successfully added!");
    },
    error: function(textStatus, errorThrown){
      alert("Status:" + textStatus);
      alert("Error:" + errorThrown);
    }

  });
}
})

function photo(){

  navigator.camera.getPicture(onSuccess, onFail, { quality: 50,
      destinationType: Camera.DestinationType.FILE_URI });
  
  function onSuccess(imageURI) {
      var image = document.getElementById('myImage');
      image.src = imageURI;
  }
  
  function onFail(message) {
      alert('Failed because: ' + message);
  }
  
  }
  
/*
function getPicture() {
    navigator.camera.getPicture(succeededCameraCallback, failedCameraCallback, {
        quality: 25,
        destinationType: Camera.DestinationType.DATA_URL
    });
}

function succeededCameraCallback(imageData) {
  
  document.querySelector('#myImage2').attr('src', 'data:image/jpeg;base64,' + imageData);
  document.querySelector('#myImage2').css('display', 'block');
  document.querySelector('#myImage2').show();
}

function failedCameraCallback(message) {
    alert('Error: ' + message);
}

*/
