document.addEventListener('init', function(event) {

    
     ons.ready(function() {
        document.getElementById("deviceInfo").innerHTML = "Version"  + " - " + device.model + "  " +  "Platform" + " - "  +   device.platform;
        document.getElementById("batteryInfo").innerHTML = "Level: " + status.level + " isPlugged: " + status.isPlugged;
        //document.getElementById("level").innerHTML = "Battery Level Low " + status.level + "%";
        });
    });