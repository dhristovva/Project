
export const NotFoundPage = {
  props: ['components', 'categories', 'id', 'query'],
  template: `
    <div class="pv-content">
      <h2 class="pv-content__header">Not Found</h2>
    </div>
  `,
};
